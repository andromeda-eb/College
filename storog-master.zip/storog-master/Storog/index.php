<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Storog</title>
        <link rel="stylesheet" type="text/css" href="css/main.css">
    </head>
    
    <body>
        <?php
            include "includes/header.php";
        ?>
        
        <main class="wide">
            
        </main>
    </body>
</html>
