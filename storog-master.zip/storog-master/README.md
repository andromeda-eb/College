# storog

Repository details:

Json_Parse:
Older version of store_parse

Storog:
Netbeans project folder for the site

store_parse:
Netbeans project which parses the online stores Steam and GOG. Outputs a file
called insert_statements.sql for populating our database with all the games
from the sites. Using this .sql file is not recommended as adding the games
can take a long time. Their is also a lot of junk data included.

storog_db_dkit.sql:
Dump of the database used for the site made using PHPMyAdmin.
