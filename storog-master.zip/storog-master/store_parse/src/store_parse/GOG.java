package store_parse;

public class GOG{
    public GOG(){
        
    }
    
    @Override
    public String toString(){
        return String.format("gog:{}");
    }
}
